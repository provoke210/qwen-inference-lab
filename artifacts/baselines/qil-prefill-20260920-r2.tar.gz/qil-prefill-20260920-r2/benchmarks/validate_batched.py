"""Validate mixed-length batched decode against a local Transformers checkpoint.

Uses identical teacher-forced prefixes for logit comparison, then checks complete
greedy generation separately. No tokenizer or network access is needed here.
"""
import argparse
import gc
import hashlib
import json
from pathlib import Path
import platform

import torch
from qil import Engine, Qwen3


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--model', required=True)
    parser.add_argument('--workload', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--device', default='cuda')
    parser.add_argument('--dtype', choices=['float32', 'bfloat16'], default='float32')
    args = parser.parse_args()
    from transformers import Qwen3ForCausalLM
    dtype = getattr(torch, args.dtype)
    torch.manual_seed(0)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    workload = json.loads(args.workload.read_text())
    source = next(case['prompts'] for case in workload['performance'] if case['batch'] == 4)
    prompts = [tokens[:length] for tokens, length in zip(source, [17, 41, 83, 128])]
    count = 8
    reference = Qwen3ForCausalLM.from_pretrained(
        args.model, local_files_only=True, torch_dtype=dtype,
        attn_implementation='eager').to(args.device).eval()
    expected_tokens, reference_logits = [], []
    with torch.inference_mode():
        for prompt in prompts:
            tokens, logits_by_step = list(prompt), []
            for _ in range(count):
                logits = reference(torch.tensor([tokens], device=args.device), use_cache=False).logits[0, -1]
                logits_by_step.append(logits.float().cpu())
                tokens.append(int(logits.argmax().item()))
            expected_tokens.append(tokens[len(prompt):])
            reference_logits.append(logits_by_step)
    del reference, logits
    gc.collect()
    if args.device.startswith('cuda'):
        torch.cuda.empty_cache()
    model = Qwen3.from_directory(args.model, device=args.device, dtype=dtype)
    owner = Engine(model, num_pages=128, page_size=16)
    pool = owner.pool
    for rid, prompt in enumerate(prompts):
        assert pool.admit(rid, len(prompt) + count)
    # Interleaved allocation exercises noncontiguous request page tables.
    for start in range(0, max(map(len, prompts)), 16):
        for rid, prompt in enumerate(prompts):
            chunk = prompt[start:start + 16]
            if chunk:
                pool.ensure(rid, start + len(chunk))
                model(chunk, start=start, pool=pool, request_id=rid)
    checks = []
    atol, rtol = (2e-4, 2e-4) if dtype == torch.float32 else (0.25, 0.02)
    for step in range(count - 1):
        ids = list(range(4)) if step % 2 else list(reversed(range(4)))
        starts = [len(prompts[rid]) + step for rid in ids]
        for rid, start in zip(ids, starts):
            pool.ensure(rid, start + 1)
        logits = model.forward_decode([expected_tokens[rid][step] for rid in ids],
                                      starts=starts, pool=pool, request_ids=ids).cpu()
        for row, rid in enumerate(ids):
            target = reference_logits[rid][step + 1]
            error = (logits[row] - target).abs()
            checks.append(dict(request_id=rid, step=step + 1,
                max_abs_error=float(error.max()), mean_abs_error=float(error.mean()),
                finite=bool(torch.isfinite(logits[row]).all()),
                within_tolerance=bool(torch.allclose(logits[row], target, atol=atol, rtol=rtol)),
                argmax_match=int(logits[row].argmax()) == int(target.argmax())))
    for rid in range(4):
        pool.release(rid)
    assert not pool.tables and len(pool.free) == pool.capacity
    del owner, pool, logits
    if args.device.startswith('cuda'):
        torch.cuda.empty_cache()
    generations = []
    for enabled in (False, True):
        engine = Engine(model, num_pages=128, page_size=16, token_budget=512,
                        prefill_chunk=128, max_active=4, batch_decode=enabled)
        try:
            rows = engine.generate(prompts, max_new_tokens=count, ignore_eos=True)
            generations.append(dict(batch_decode=enabled, token_ids=[row['token_ids'] for row in rows],
                exact_match=[row['token_ids'] == expected for row, expected in zip(rows, expected_tokens)],
                all_pages_released=not engine.pool.tables and len(engine.pool.free) == 128))
        finally:
            engine.close()
        del engine
    root = Path(__file__).resolve().parents[1]
    source_names = ['qil/__init__.py', 'qil/config.py', 'qil/cache.py', 'qil/scheduler.py',
                    'qil/model.py', 'qil/engine.py', 'benchmarks/validate_batched.py']
    report = dict(device=args.device, dtype=args.dtype, model=args.model, python=platform.python_version(),
        torch=torch.__version__, gpu=torch.cuda.get_device_name() if args.device.startswith('cuda') else None,
        prompt_token_ids=prompts, expected_token_ids=expected_tokens, logit_checks=checks,
        tolerance=dict(atol=atol, rtol=rtol), generations=generations,
        source_sha256={name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in source_names},
        scope='Mixed-length teacher-forced logits and greedy output correctness; not a speed benchmark')
    report['passed'] = (all(row['finite'] and row['within_tolerance'] for row in checks)
                        and all(all(row['exact_match']) and row['all_pages_released'] for row in generations))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(dict(passed=report['passed'], dtype=args.dtype,
        max_logit_abs_error=max(row['max_abs_error'] for row in checks),
        generation_exact=[row['exact_match'] for row in generations])))
    if not report['passed']:
        raise SystemExit('Correctness checks differ; inspect the saved report')


if __name__ == '__main__':
    main()
